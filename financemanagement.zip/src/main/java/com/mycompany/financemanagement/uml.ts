class hello{
    int name;
}