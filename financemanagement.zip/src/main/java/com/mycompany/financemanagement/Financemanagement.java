/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.financemanagement;

/**
 *
 * @author nithi
 */
public class Financemanagement {

    public static void main(String[] args) {
        System.out.println("Hello World!");
        
        loginpage page = new loginpage();
        page.setVisible(true);
    }
    
}
